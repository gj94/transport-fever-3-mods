function data()
return {updateScript={fileName="wap7_transformator.script@wap7.updateFn",params={}},updateParticleSystemScript={fileName="::/vehicle/train/shared/transformator_train.script@train.updateParticleSystemFn",params={}}}
end

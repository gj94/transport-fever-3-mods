function data()
return {updateScript={fileName="wag9_transformator.script@wag9.updateFn",params={}},updateParticleSystemScript={fileName="::/vehicle/train/shared/transformator_train.script@train.updateParticleSystemFn",params={}}}
end

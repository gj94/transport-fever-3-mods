function data()
return {updateScript={fileName="vb_transformator.script@vb.updateFn",params={}},updateParticleSystemScript={fileName="::/vehicle/train/shared/transformator_train.script@train.updateParticleSystemFn",params={}}}
end

function data()
return {updateScript={fileName="wag12b_transformator.script@wag12b.updateFn",params={}},updateParticleSystemScript={fileName="::/vehicle/train/shared/transformator_train.script@train.updateParticleSystemFn",params={}}}
end

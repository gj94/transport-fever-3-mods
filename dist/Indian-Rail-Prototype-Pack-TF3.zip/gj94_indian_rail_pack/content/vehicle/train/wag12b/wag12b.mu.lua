function data()
return {vehicles={{name="gj94_indian_rail_pack::/vehicle/train/wag12b_a/wag12b_a.mdl",forward=true},{name="gj94_indian_rail_pack::/vehicle/train/wag12b_b/wag12b_b.mdl",forward=false}},name="Indian Railways WAG-12B (twin section)",desc="Gameplay-upgraded twin-section electric freight locomotive. 16,000 kW, 1,000 kN, 180 t, 200 km/h. Requires electrified track; add freight wagons.",filterTags={"default"}}
end

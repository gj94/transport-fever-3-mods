function data()
return {
  type = "react-plugin ::ModEntryPointExtension",
  data = { filePath = resolve("indian_rail_vehicle_section.script@EntryPoint"), order = -100 },
}
end

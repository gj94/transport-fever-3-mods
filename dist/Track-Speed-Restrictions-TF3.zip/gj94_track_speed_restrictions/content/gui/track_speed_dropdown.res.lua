function data()
return {
  type = "react-plugin ::ModEntryPointExtension",
  data = { filePath = resolve("track_speed_dropdown.script@EntryPoint"), order = -100 },
}
end

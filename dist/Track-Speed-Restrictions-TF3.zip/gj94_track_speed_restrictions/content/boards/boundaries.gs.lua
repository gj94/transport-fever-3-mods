function data()
return {
  updateScript = { fileName = "boundaries.script@update" },
  postUpdateScript = { fileName = "boundaries.script@postUpdate" },
  handleEventScript = { fileName = "boundaries.script@handleEvent" },
}
end

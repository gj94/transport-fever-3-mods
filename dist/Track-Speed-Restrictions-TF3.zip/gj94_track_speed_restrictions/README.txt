TRACK SPEED RESTRICTIONS - TF3

Enable this mod when starting or loading a game.
In the track menu choose a stock track, then select Speed limit from its dropdown.
Default uses the normal stock limit. Other choices are 15-160 km/h.
Use track replacement/upgrade on an existing section, or lay a new section.
For electric trains select the electrified variant; adding/removing wires preserves the cap.
Stock availability years still apply. Curves, bridges and train ratings can impose lower limits.
Both travel directions share the limit. Decorative signs do not enforce restrictions.
Replace every restricted track with stock track before removing this mod from a save.
Revision 1 tracks remain registered and keep their saved limits.
Revision 3 corrects the Lua script data() export required at startup.
Revision 1 track operation was user-confirmed; the dropdown still needs a play test.

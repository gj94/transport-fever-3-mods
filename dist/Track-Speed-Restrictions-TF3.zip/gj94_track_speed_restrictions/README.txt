TRACK SPEED RESTRICTIONS - TF3

Enable this mod when starting or loading a game.
In the track menu choose a stock track, then select Speed limit from its dropdown.
Default uses the normal stock limit. Other choices are 15-160 km/h.
Use track replacement/upgrade on an existing section, or lay a new section.
For electric trains select the electrified variant; adding/removing wires preserves the cap.
Stock availability years still apply. Curves, bridges and train ratings can impose lower limits.
Both travel directions share the limit. Numbered boards appear at section entrances.
Numbers face outward toward approaching trains. The backs are blank for departing trains.
Contiguous track of the same custom speed is one section, including style/wire changes.
Default track has no custom-speed boards. Track edits automatically refresh the boundaries.
Boards are visual custom entities; they do not change signals, caps or noise barriers.
Tunnel interiors have no boards. Existing custom-speed tracks are detected on loading.
Replace every restricted track with stock track before removing this mod from a save.
Revision 1 tracks remain registered and keep their saved limits.
Revision 4 adds original numbered boards, preserving all previous track resource names and caps.
Revision 5 fixes the runtime track scan by reading the native track graph.
Revision 5 track speeds, dropdown and entrance boards were user-confirmed in game on 30 September 2026.

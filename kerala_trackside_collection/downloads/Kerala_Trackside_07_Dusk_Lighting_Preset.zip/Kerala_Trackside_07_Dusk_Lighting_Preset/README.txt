KERALA CANAL AT DUSK
Lighting preset and rendered companion image

This is a lighting-only variation of the approved canal showcase. The cool evening sky, low warm residual sun and restrained tea-shop/verandah practical lights reveal the existing materials and furnished service area. The original procedural backwater reflects the changed lighting naturally.

The model geometry, instance placement, camera, material nodes and packed surface maps are unchanged. The preset never writes a BLEND file. It loads the existing packed scene, adds presentation lights in memory, renders, and verifies that the original scene file still has the same SHA-256. Geometry/instance and material/map fingerprints are also compared before and after lighting changes.

Required scene
Extract Kerala_Trackside_04A_Showcase_Blender beside this pack. Its file is Kerala_Trackside_Showcase.blend. The preset searches nearby sibling folders for that exact pack name. Otherwise pass the full scene path explicitly.

Draft example
blender -b -t 2 --python render_dusk.py -- --scene /path/to/Kerala_Trackside_Showcase.blend

Final example
blender -b -t 2 --python render_dusk.py -- --scene /path/to/Kerala_Trackside_Showcase.blend --final --width 1920 --samples 128

Use the actual path to render_dusk.py if it is inside a scripts folder. An optional --output /path/to/image.png chooses a different image destination. Without it, the PNG and verification manifest are written beside the script. Two CPU render threads are used. Blender 4.3.2 was used for the supplied image; no additional Python packages, textures or HDRIs are required. Cycles denoising is disabled for portability, with adaptive sampling and a modest indirect-firefly clamp.

The default guard accepts only the approved 04A scene hash. For a scene you have deliberately edited yourself, --allow-modified-scene bypasses that initial guard, while still verifying that your file and its geometry/material state are unchanged by this lighting pass.

Base scene SHA-256
0a6d99ecc9acc8e17bacb732820895610ce20f146c6987f0b179cbc59c1142bd

This remains an original fictional Kerala-inspired composition, not a surveyed railway location or an engineering reference. The source scene and individual asset packs retain their own reference and font notices.

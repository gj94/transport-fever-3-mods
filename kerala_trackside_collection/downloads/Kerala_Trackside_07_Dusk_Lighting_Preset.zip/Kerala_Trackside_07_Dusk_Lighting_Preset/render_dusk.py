"""Reversible dusk lighting for the approved Kerala canal showcase.
Run from a fresh Blender process. This script never saves a BLEND or edits maps.
Example: blender -b -t 2 --python render_dusk.py -- --scene /path/to/Kerala_Trackside_Showcase.blend --final
"""
import bpy, argparse, sys, math, json, hashlib, array
from pathlib import Path
from mathutils import Vector
HERE=Path(__file__).resolve().parent
BASE_SHA='0a6d99ecc9acc8e17bacb732820895610ce20f146c6987f0b179cbc59c1142bd'
p=argparse.ArgumentParser();p.add_argument('--scene',type=Path);p.add_argument('--final',action='store_true');p.add_argument('--width',type=int);p.add_argument('--samples',type=int);p.add_argument('--output',type=Path);p.add_argument('--allow-modified-scene',action='store_true');a=p.parse_args(sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else [])
if a.scene:scene_path=a.scene.expanduser().resolve()
else:
 candidates=[HERE.parent/'Kerala_Trackside_04A_Showcase_Blender'/'Kerala_Trackside_Showcase.blend',HERE.parent.parent/'release'/'showcase'/'Kerala_Trackside_Showcase.blend',HERE.parent/'04A_Showcase_Blender'/'Kerala_Trackside_Showcase.blend']
 for parent in list(HERE.parents)[:3]:
  candidates.append(parent/'Kerala_Trackside_04A_Showcase_Blender'/'Kerala_Trackside_Showcase.blend')
 scene_path=next((x for x in candidates if x.is_file()),None)
 if scene_path is None:raise FileNotFoundError('Pass --scene with the extracted 04A showcase BLEND path.')
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
base_before=sha(scene_path)
if not a.allow_modified_scene:assert base_before==BASE_SHA,'Scene differs from approved base; use --allow-modified-scene only for your own edited copy.'
bpy.ops.wm.open_mainfile(filepath=str(scene_path));s=bpy.context.scene
# Fingerprint all existing mesh coordinates/topology, transforms and material nodes/maps.
# New light objects, world and compositor nodes are intentionally excluded.
def geometry_fingerprint():
 h=hashlib.sha256()
 for m in sorted(bpy.data.meshes,key=lambda x:x.name):
  h.update(m.name.encode());co=array.array('f',[0])*(len(m.vertices)*3);m.vertices.foreach_get('co',co);h.update(co.tobytes());vi=array.array('i',[0])*len(m.loops);m.loops.foreach_get('vertex_index',vi);h.update(vi.tobytes())
 for o in sorted((o for o in bpy.data.objects if o.type not in ('LIGHT','CAMERA')),key=lambda x:x.name):h.update(repr((o.name,tuple(tuple(row) for row in o.matrix_world),o.instance_collection.name if o.instance_collection else '')).encode())
 return h.hexdigest()
def material_fingerprint():
 h=hashlib.sha256()
 for m in sorted(bpy.data.materials,key=lambda x:x.name):
  h.update(m.name.encode())
  if m.use_nodes:
   for n in m.node_tree.nodes:
    h.update(repr((n.name,n.bl_idname)).encode())
    for i in n.inputs:
     if hasattr(i,'default_value'):
      v=i.default_value
      try:v=tuple(v)
      except TypeError:pass
      h.update(repr((i.identifier,v)).encode())
   h.update(repr(sorted((l.from_node.name,l.from_socket.identifier,l.to_node.name,l.to_socket.identifier) for l in m.node_tree.links)).encode())
 for im in sorted(bpy.data.images,key=lambda x:x.name):
  if im.packed_file:h.update(im.name.encode());h.update(bytes(im.packed_file.data))
 return h.hexdigest()
geometry_before=geometry_fingerprint();materials_before=material_fingerprint()
# Only the copied in-memory presentation world and compositor are altered.
w=s.world.copy();w.name='DUSK_Cool_evening_sky';s.world=w;w.use_nodes=True;nt=w.node_tree;nt.nodes.clear()
coord=nt.nodes.new('ShaderNodeTexCoord');sep=nt.nodes.new('ShaderNodeSeparateXYZ');nt.links.new(coord.outputs['Normal'],sep.inputs[0])
ramp=nt.nodes.new('ShaderNodeValToRGB');ramp.color_ramp.elements[0].position=.0;ramp.color_ramp.elements[0].color=(.22,.265,.35,1);ramp.color_ramp.elements[1].position=.8;ramp.color_ramp.elements[1].color=(.05,.085,.16,1);nt.links.new(sep.outputs['Z'],ramp.inputs[0])
bg=nt.nodes.new('ShaderNodeBackground');bg.inputs[1].default_value=.85;nt.links.new(ramp.outputs['Color'],bg.inputs[0]);out=nt.nodes.new('ShaderNodeOutputWorld');nt.links.new(bg.outputs[0],out.inputs['Surface'])
sun=bpy.data.objects.get('Soft_afternoon_sun');sun.data=sun.data.copy();sun.data.energy=.25;sun.data.color=(1,.72,.46);sun.data.angle=math.radians(10);sun.rotation_euler=(math.radians(78),math.radians(-12),math.radians(-35))
fill=bpy.data.objects.get('Sky_fill');fill.data=fill.data.copy();fill.data.energy=1400;fill.data.color=(.48,.64,1)
for n in s.node_tree.nodes:
 if n.bl_idname=='CompositorNodeMixRGB':n.inputs[2].default_value=(.105,.15,.225,1)
 if n.bl_idname=='CompositorNodeMath' and n.operation=='MULTIPLY':n.inputs[1].default_value=.42
# Practical illumination is anchored to the existing placed collection transforms.
lights=bpy.data.collections.new('DUSK_Additional_Practical_Lights');s.collection.children.link(lights);records=[]
def instance(aid):return next(o for o in s.objects if o.instance_type=='COLLECTION' and o.instance_collection and o.instance_collection.name==aid)
def area(name,inst,loc,target,power,size,size_y,color):
 d=bpy.data.lights.new(name,'AREA');d.energy=power;d.color=color;d.shape='RECTANGLE';d.size=size;d.size_y=size_y;o=bpy.data.objects.new(name,d);lights.objects.link(o);o.location=inst.matrix_world@Vector(loc);aim=inst.matrix_world@Vector(target);o.rotation_euler=(aim-o.location).to_track_quat('-Z','Y').to_euler();records.append({'name':name,'asset_instance':inst.name,'local_position_m':loc,'local_aim_m':target,'power_W':power,'size_m':[size,size_y],'linear_rgb':color})
tea=instance('BLD_TeaShop_Open_01');home=instance('BLD_Home_Verandah_01');concrete=instance('BLD_Home_Concrete_01')
area('DUSK_TeaShop_existing_tube',tea,(0,0,2.51),(0,.1,.8),55,1.25,.16,(1,.80,.60))
area('DUSK_TeaShop_counter_bounce',tea,(.35,-2.30,2.35),(.2,-.6,1.35),28,1.1,.22,(1,.72,.43))
for x in [-2.0,2.0]:area('DUSK_Verandah_practical_'+str(x),home,(x,-2.95,2.68),(x,-2.45,.6),30,.3,.3,(1,.72,.43))
area('DUSK_Concrete_porch',concrete,(0,-2.7,2.50),(0,-2.3,.6),18,.3,.3,(1,.75,.48))
s.camera=bpy.data.objects['CAM_canal'];s.render.engine='CYCLES';s.render.threads_mode='FIXED';s.render.threads=2;s.cycles.use_denoising=False;s.cycles.sample_clamp_indirect=3;s.cycles.use_adaptive_sampling=True;s.cycles.adaptive_threshold=.025 if a.final else .08;s.cycles.samples=a.samples or (128 if a.final else 32);s.render.resolution_x=a.width or (1920 if a.final else 960);s.render.resolution_y=round(s.render.resolution_x*2/3);s.render.resolution_percentage=100;s.view_settings.view_transform='AgX';s.view_settings.exposure=.65
s.render.image_settings.file_format='PNG';s.render.image_settings.color_mode='RGB';s.render.image_settings.color_depth='8';s.render.film_transparent=False
output=(a.output or HERE/('Kerala_Canal_Dusk_Final.png' if a.final else 'Kerala_Canal_Dusk_Draft.png')).resolve();output.parent.mkdir(parents=True,exist_ok=True);s.render.filepath=str(output)
assert geometry_fingerprint()==geometry_before,'Geometry or placement changed';assert material_fingerprint()==materials_before,'Asset material/map changed'
print('DUSK_RENDER_BEGIN',str(output),flush=True);bpy.ops.render.render(write_still=True)
assert sha(scene_path)==base_before,'Base file changed on disk'
report={'status':'rendered_pending_visual_qa','image':output.name,'image_sha256':sha(output),'resolution_px':[s.render.resolution_x,s.render.resolution_y],'samples':s.cycles.samples,'adaptive_threshold':s.cycles.adaptive_threshold,'indirect_clamp':s.cycles.sample_clamp_indirect,'exposure':s.view_settings.exposure,'threads':2,'base_scene_filename':scene_path.name,'base_scene_sha256_before':base_before,'base_scene_sha256_after':sha(scene_path),'base_file_unchanged':True,'mesh_and_instance_fingerprint_unchanged':geometry_fingerprint()==geometry_before,'material_and_map_fingerprint_unchanged':material_fingerprint()==materials_before,'geometry_fingerprint':geometry_before,'material_map_fingerprint':materials_before,'camera':'CAM_canal (unchanged transform/lens)','world':'Cool gradient sky; warm low residual sun; reduced cool presentation fill','sky_strength':.85,'sun_strength':.25,'sky_fill_W':1400,'preset_script_sha256':sha(Path(__file__)),'practical_lights':records,'note':'Existing approved asset geometry, material nodes and packed image maps remain unchanged. This script renders in memory and never saves a BLEND. Water shading is original; reflections respond naturally to the changed lighting.'}
(HERE/('dusk_final_manifest.json' if a.final else 'dusk_draft_manifest.json')).write_text(json.dumps(report,indent=2)+'\n');print('DUSK_COMPLETE',json.dumps(report),flush=True)

# Evidence and dimensional interpretation

Research and visual inspection: 9 October 2026. The utility pack is an original scenic interpretation of civilian infrastructure seen in Kerala. It is not an electrical installation guide, a surveyed site, an equipment specification, or railway electrification.

## Documentary anchors

1. KSERC's KSEB distribution cost data, 8 February 2024, lists ordinary LT insertion components. PDF page 17 identifies a two-line arrangement using one pin insulator and one reel; page 20 identifies a four-line arrangement using three pin insulators and one reel. KR_U01 uses the latter count. The source gives bills of materials rather than a complete mounting drawing. Page 71 specifies a separate two-pin channel component of 75 × 40 × 6 mm and 0.510 m length in an HT/ABC bill; the mini-pack's four-line 1.10 m arm is an artistic estimate, not that sourced part length. The PDF was downloaded and relevant pages visually checked during research. https://dev.erckerala.org/api/storage/orders/wKWPEhHjiwCEPghW8rchrdngxNkHM3b8Hka6037k.pdf

2. A historical Kerala PWD tender's indexed text gives a 9 m PSC shaft with 315 × 105 mm bottom and 115 × 105 mm top sections. The original PDF drawing could not be retrieved for visual inspection. This is only a shape/proportion anchor. The model uses a linear tapered visible section 7.5 m high, approximately 281.7 × 105 mm at its modeled foot and 115 × 105 mm at its top. That is an authored interpretation assuming an omitted lower portion, not a verified current 8 m KSEB pole standard or a prescribed embedment. https://www.keralapwd.gov.in/intranet/compRepository/mediagallery/tenders/Doc_poles.pdf

3. KSEB's historical labour data supports the use of double-pole transformer structures, pole-mounted lamps and yellow pole-number backgrounds. It also records variations in lower-pole markings. The pack uses only a restrained yellow number patch with original fictional lettering. https://old.kseb.in/index.php?catid=2&id=1007&lang=en&m=0&option=com_jdownloads&task=download.send

4. KSEB's NILAAVU order, 14 May 2021, establishes modern pole-mounted LED lights in Kerala. It does not establish the particular lamp's shape or dimensions, and no wattage is assigned to KR_U03. https://old.kseb.in/index.php?catid=2&id=18505&lang=en&m=0&option=com_jdownloads&task=download.send

## Photographs actually inspected

- The pole close-up in a Kerala LiveLaw report shows tapered rough-grey concrete, dark channel crossarms, straps/bolts and brown-black ceramic forms. Its dense multi-direction junction wiring was deliberately not copied as an ordinary LT arrangement. https://www.livelaw.in/news-updates/kerala-high-court-quashed-kseb-plan-to-procure-lower-workload-poles-177611
- A Thrissur photograph dated 6 February 2025 shows an elevated compact grey transformer, vertical cooling fins, two-upright steel support and a long shallow pale lamp on a short outreach arm. Its support material is not conclusively identifiable from the photograph alone; the model's two PSC uprights are an original combination supported by the documentary double-pole context. https://www.manoramaonline.com/district-news/thrissur/2025/02/06/villadam-ayurveda-hospital-reopens.html
- The Genisys contractor portfolio's KSEB transformer photograph shows a pale-grey tank, pronounced vertical fins, lid flange/lifting details and tall brown multi-shed bushings. It does not establish the delivered model's capacity or complete installation. https://www.genisysin.com/projects.html
- A Palakkad news photograph shows a rectangular yellow hand-painted identification patch on grey concrete. The delivered identifiers are newly authored; the photograph's real number is not reproduced. https://www.manoramanews.com/kerala/latest/2023/12/30/offcicers-took-10years-to-relocate-an-electric-post-in-palakkad.html

## Authored details and limitations

Concrete texture, quiet ground dampness, glazed ceramic, weathered metal, fasteners, cable clips, warning graphics and mild coating variation were independently authored. Insulator shapes, tank dimensions, cooling-bank layout, support spacing/elevation, lamp housing, brackets and all wiring are scenic estimates. The simplified cable paths are decorative visible connections, not a functional circuit, switching arrangement or safety-clearance study. The warning board is original scenery artwork and is not certified safety signage.

Research photographs, PDFs and extracted pages are excluded from the deliverable. No reference image is used as a texture, traced decal or preview. All previews are actual renders of the original Blender geometry. Font-derived lettering is identified separately in FONT_NOTICE.txt.
